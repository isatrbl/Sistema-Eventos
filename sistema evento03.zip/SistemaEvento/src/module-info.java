/**
 * 
 */
/**
 * 
 */
module SistemaEvento {
	requires java.desktop;
}