package app;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Sistema extends JFrame {
    private List<Evento> listaEventos = new ArrayList<>();
    private DefaultListModel<String> modeloLista = new DefaultListModel<>();
    private Evento eventoSelecionado = null; 
    private final String ARQUIVO = "dados_nexus.txt";

    private CardLayout cardLayout = new CardLayout();
    private JPanel painelPrincipal = new JPanel(cardLayout);

    private JTextField txtNome, txtData, txtLocal, txtInsNome, txtInsEmail, txtInsTel;
    private JTextArea txtDesc;
    private JList<String> jlEventos;
    private JLabel lblTituloInscricao;

    public Sistema () {
        setTitle("Nexus Events Pro | Gestão de Eventos");
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        painelPrincipal.add(criarTelaLogin(), "LOGIN");
        painelPrincipal.add(criarTelaAdm(), "ADM");
        painelPrincipal.add(criarTelaInscricao(), "INSCRICAO");

        add(painelPrincipal);
        carregarDados();
        cardLayout.show(painelPrincipal, "LOGIN");
    }

    private JPanel criarTelaLogin() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(new Color(25, 25, 35));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(10, 10, 10, 10);

        JTextField user = new JTextField(15);
        JPasswordField pass = new JPasswordField(15);
        JButton btn = new JButton("Entrar no Painel");

        btn.addActionListener(e -> {
            if (user.getText().equals("admin") && new String(pass.getPassword()).equals("1234")) {
                cardLayout.show(painelPrincipal, "ADM");
            } else {
                JOptionPane.showMessageDialog(this, "Acesso Negado!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        g.gridx = 0; g.gridy = 0; p.add(new JLabel("<html><font color='white'>Usuário:</font></html>"), g);
        g.gridy = 1; p.add(user, g);
        g.gridy = 2; p.add(new JLabel("<html><font color='white'>Senha:</font></html>"), g);
        g.gridy = 3; p.add(pass, g);
        g.gridy = 4; p.add(btn, g);
        return p;
    }

    private JPanel criarTelaAdm() {
        JPanel p = new JPanel(new BorderLayout(15, 15));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel form = new JPanel(new GridLayout(0, 1, 5, 5));
        form.setBorder(BorderFactory.createTitledBorder("Gerenciar Evento"));
        txtNome = new JTextField(); txtData = new JTextField(); txtLocal = new JTextField();
        txtDesc = new JTextArea(4, 20);
        form.add(new JLabel("Nome:")); form.add(txtNome);
        form.add(new JLabel("Data:")); form.add(txtData);
        form.add(new JLabel("Local:")); form.add(txtLocal);
        form.add(new JLabel("Descrição:")); form.add(new JScrollPane(txtDesc));

        JButton btnSalvar = new JButton("Salvar / Atualizar Evento");
        btnSalvar.addActionListener(e -> acaoSalvarOuEditar());
        form.add(btnSalvar);

        jlEventos = new JList<>(modeloLista);
        JPanel listPanel = new JPanel(new BorderLayout(5, 5));
        listPanel.add(new JScrollPane(jlEventos), BorderLayout.CENTER);

        JPanel botoes = new JPanel(new GridLayout(1, 5, 5, 5));
        JButton btnEdit = new JButton("Editar");
        JButton btnDel = new JButton("Excluir");
        JButton btnInsc = new JButton("Inscrição");
        JButton btnList = new JButton("Ver Inscritos");
        JButton btnSair = new JButton("Logoff");

        btnEdit.addActionListener(e -> acaoCarregarParaEditar());
        btnDel.addActionListener(e -> acaoExcluir());
        btnInsc.addActionListener(e -> acaoIrParaInscricao()); 
        btnList.addActionListener(e -> acaoMostrarInscritos());
        btnSair.addActionListener(e -> cardLayout.show(painelPrincipal, "LOGIN"));

        botoes.add(btnEdit); botoes.add(btnDel); botoes.add(btnInsc); botoes.add(btnList); botoes.add(btnSair);
        listPanel.add(botoes, BorderLayout.SOUTH);

        p.add(form, BorderLayout.WEST);
        p.add(listPanel, BorderLayout.CENTER);
        return p;
    }

    private JPanel criarTelaInscricao() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(10, 10, 10, 10); g.fill = GridBagConstraints.HORIZONTAL;

        lblTituloInscricao = new JLabel("Inscrição Pública", SwingConstants.CENTER);
        lblTituloInscricao.setFont(new Font("Arial", Font.BOLD, 20));

        txtInsNome = new JTextField(20); txtInsEmail = new JTextField(20); txtInsTel = new JTextField(20);
        JButton btnConf = new JButton("Confirmar Inscrição");
        JButton btnVoltar = new JButton("Cancelar");

        btnConf.addActionListener(e -> acaoProcessarInscricao());
        btnVoltar.addActionListener(e -> cardLayout.show(painelPrincipal, "ADM"));

        g.gridx = 0; g.gridy = 0; g.gridwidth = 2; p.add(lblTituloInscricao, g);
        g.gridwidth = 1; g.gridy = 1; p.add(new JLabel("Nome Completo:"), g); g.gridx = 1; p.add(txtInsNome, g);
        g.gridx = 0; g.gridy = 2; p.add(new JLabel("Email:"), g); g.gridx = 1; p.add(txtInsEmail, g);
        g.gridx = 0; g.gridy = 3; p.add(new JLabel("Telefone:"), g); g.gridx = 1; p.add(txtInsTel, g);
        g.gridx = 0; g.gridy = 4; g.gridwidth = 2; p.add(btnConf, g);
        g.gridy = 5; p.add(btnVoltar, g);
        return p;
    }

    private void acaoSalvarOuEditar() {
        if (txtNome.getText().isEmpty()) return;
        if (eventoSelecionado == null) {
            Evento novo = new Evento(txtNome.getText(), txtDesc.getText(), txtData.getText(), txtLocal.getText());
            listaEventos.add(novo);
            modeloLista.addElement(novo.getNome());
        } else {
            eventoSelecionado.setNome(txtNome.getText());
            eventoSelecionado.setData(txtData.getText());
            eventoSelecionado.setLocal(txtLocal.getText());
            eventoSelecionado.setDescricao(txtDesc.getText());
            atualizarListaVisual();
            eventoSelecionado = null;
        }
        salvarDados();
        limparCamposAdm();
    }

    private void acaoCarregarParaEditar() {
        int i = jlEventos.getSelectedIndex();
        if (i == -1) return;
        eventoSelecionado = listaEventos.get(i);
        txtNome.setText(eventoSelecionado.getNome());
        txtData.setText(eventoSelecionado.getData());
        txtLocal.setText(eventoSelecionado.getLocal());
        txtDesc.setText(eventoSelecionado.getDescricao());
    }

    private void acaoExcluir() {
        int i = jlEventos.getSelectedIndex();
        if (i != -1) {
            listaEventos.remove(i);
            modeloLista.remove(i);
            salvarDados();
        }
    }

    private void acaoIrParaInscricao() {
        int i = jlEventos.getSelectedIndex();
  
        if (i == -1) {
            eventoSelecionado = null; 
            lblTituloInscricao.setText("MODO DE TESTE: EVENTO INEXISTENTE");
        } else {
            eventoSelecionado = listaEventos.get(i);
            lblTituloInscricao.setText("Inscrição: " + eventoSelecionado.getNome());
        }
        cardLayout.show(painelPrincipal, "INSCRICAO");
    }

    private void acaoProcessarInscricao() {
        String nome = txtInsNome.getText().trim();
        
        if (eventoSelecionado.jaEstaInscrito(nome)) {
            JOptionPane.showMessageDialog(this, "Erro: Participante já cadastrado!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        eventoSelecionado.adicionarInscrito(nome, txtInsEmail.getText(), txtInsTel.getText());
        salvarDados();
        JOptionPane.showMessageDialog(this, "Inscrição realizada com sucesso!");
        cardLayout.show(painelPrincipal, "ADM");
    }

    private void acaoMostrarInscritos() {
        int i = jlEventos.getSelectedIndex();
        if (i == -1) return;
        Evento ev = listaEventos.get(i);
        StringBuilder sb = new StringBuilder("Lista de Inscritos - " + ev.getNome() + ":\n\n");
        for (String s : ev.getInscritos()) sb.append("- ").append(s.replace("|", " | ")).append("\n");
        JOptionPane.showMessageDialog(this, sb.length() > 30 ? sb.toString() : "Nenhum inscrito ainda.");
    }

    private void atualizarListaVisual() {
        modeloLista.clear();
        for (Evento e : listaEventos) modeloLista.addElement(e.getNome());
    }

    private void limparCamposAdm() {
        txtNome.setText(""); txtData.setText(""); txtLocal.setText(""); txtDesc.setText("");
    }

    private void salvarDados() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARQUIVO))) {
            for (Evento e : listaEventos) {
                pw.println(e.getNome() + ";" + e.getDescricao() + ";" + e.getData() + ";" + 
                           e.getLocal() + ";" + e.getInscritosFormatados());
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void carregarDados() {
        File f = new File(ARQUIVO);
        if (!f.exists()) return;
        try (Scanner sc = new Scanner(f)) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(";", -1);
                if (p.length >= 4) {
                    Evento ev = new Evento(p[0], p[1], p[2], p[3]);
                    if (p.length == 5) ev.carregarInscritos(p[4]);
                    listaEventos.add(ev);
                    modeloLista.addElement(ev.getNome());
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}