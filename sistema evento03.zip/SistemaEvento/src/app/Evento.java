package app;

import java.util.ArrayList;
import java.util.List;

public class Evento {
    private String nome, descricao, data, local;
    private List<String> inscritos; 
    public Evento(String nome, String descricao, String data, String local) {
        this.nome = nome;
        this.descricao = descricao;
        this.data = data;
        this.local = local;
        this.inscritos = new ArrayList<>();
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }
    public List<String> getInscritos() { return inscritos; }

    public boolean jaEstaInscrito(String nomeBusca) {
        for (String s : inscritos) {
            String nomeInscrito = s.split("\\|")[0];
            if (nomeInscrito.equalsIgnoreCase(nomeBusca.trim())) return true;
        }
        return false;
    }

    public void adicionarInscrito(String nome, String email, String tel) {
        this.inscritos.add(nome.trim() + "|" + email.trim() + "|" + tel.trim());
    }

    public String getInscritosFormatados() {
        return String.join(",", inscritos);
    }

    public void carregarInscritos(String dadosBrutos) {
        if (dadosBrutos == null || dadosBrutos.isEmpty()) return;
        String[] partes = dadosBrutos.split(",");
        for (String p : partes) {
            if (!p.isEmpty()) this.inscritos.add(p);
        }
    }
}