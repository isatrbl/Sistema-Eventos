package app;

import java.util.ArrayList;
import java.util.List;

public class Evento {
    private String nome, descricao, data, local;
    private List<String> inscritos;

    public Evento(String nome, String descricao, String data, String local) {
        this.nome = nome;
        this.descricao = descricao;
        this.data = data;
        this.local = local;
        this.inscritos = new ArrayList<>();
    }

    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public String getData() { return data; }
    public String getLocal() { return local; }
    public List<String> getInscritos() { return inscritos; }

    public void adicionarInscrito(String nome) { this.inscritos.add(nome); }
    
    // Transforma a lista de nomes em "Nome1,Nome2,Nome3" para salvar no arquivo
    public String getInscritosFormatados() {
        return String.join(",", inscritos);
    }

    public void setInscritos(String[] nomes) {
        for(String n : nomes) if(!n.isEmpty()) this.inscritos.add(n);
    }
}