package app;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Sistema extends JFrame {
    private List<Evento> listaEventos = new ArrayList<>();
    private DefaultListModel<String> modeloLista = new DefaultListModel<>();
    private Evento eventoSelecionado = null;
    private final String ARQUIVO = "dados_eventos.txt";

    //Interface
    private JPanel painelPrincipal;
    private CardLayout cardLayout;
    private JList<String> jlEventos;
    private JTextField txtNome, txtData, txtLocal, txtInscritoNome;
    private JTextArea txtDesc;
    private JLabel lblEventoTitulo, lblEventoDetalhes;

    public Sistema() {
        setTitle("Nexus Events | Gerenciador de Eventos");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        painelPrincipal = new JPanel(cardLayout);

        painelPrincipal.add(criarTelaAdm(), "ADM");
        painelPrincipal.add(criarTelaInscricao(), "INSCRICAO");

        add(painelPrincipal);
        carregarDados();
    }

    //PAINEL ADMINISTRATIVO 
    private JPanel criarTelaAdm() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Formulário 
        JPanel form = new JPanel(new GridLayout(0, 1, 5, 5));
        form.setBorder(BorderFactory.createTitledBorder("Cadastrar Novo Evento"));
        
        txtNome = new JTextField();
        txtDesc = new JTextArea(3, 20);
        txtData = new JTextField();
        txtLocal = new JTextField();

        form.add(new JLabel("Nome do Evento:")); form.add(txtNome);
        form.add(new JLabel("Descrição:")); form.add(new JScrollPane(txtDesc));
        form.add(new JLabel("Data:")); form.add(txtData);
        form.add(new JLabel("Local:")); form.add(txtLocal);

        JButton btnSalvar = new JButton("Publicar Evento");
        btnSalvar.setBackground(new Color(138, 43, 226));
        btnSalvar.setForeground(Color.BLUE);
        btnSalvar.addActionListener(e -> cadastrarEvento());
        form.add(btnSalvar);

        JPanel listaPainel = new JPanel(new BorderLayout(5, 5));
        listaPainel.setBorder(BorderFactory.createTitledBorder("Eventos Ativos"));
        jlEventos = new JList<>(modeloLista);
        listaPainel.add(new JScrollPane(jlEventos), BorderLayout.CENTER);

        JPanel acoes = new JPanel(new GridLayout(1, 2, 5, 5));
        JButton btnSimular = new JButton("Simular Inscrição ->");
        JButton btnInscritos = new JButton("Listar Inscritos");

        btnSimular.addActionListener(e -> irParaInscricao());
        btnInscritos.addActionListener(e -> mostrarInscritos());

        acoes.add(btnSimular);
        acoes.add(btnInscritos);
        listaPainel.add(acoes, BorderLayout.SOUTH);

        p.add(form, BorderLayout.WEST);
        p.add(listaPainel, BorderLayout.CENTER);
        return p;
    }

    // INSCRIÇÃO
    private JPanel criarTelaInscricao() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(new Color(245, 245, 250));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        lblEventoTitulo = new JLabel("NOME DO EVENTO", SwingConstants.CENTER);
        lblEventoTitulo.setFont(new Font("SansSerif", Font.BOLD, 26));
        
        lblEventoDetalhes = new JLabel("Data | Local", SwingConstants.CENTER);
        lblEventoDetalhes.setForeground(Color.GRAY);

        txtInscritoNome = new JTextField(20);
        JButton btnConfirmar = new JButton("Confirmar Minha Vaga");
        JButton btnVoltar = new JButton("Cancelar");

        btnConfirmar.addActionListener(e -> realizarInscricao());
        btnVoltar.addActionListener(e -> cardLayout.show(painelPrincipal, "ADM"));

        gbc.gridy = 0; p.add(lblEventoTitulo, gbc);
        gbc.gridy = 1; p.add(lblEventoDetalhes, gbc);
        gbc.gridy = 2; p.add(new JSeparator(), gbc);
        gbc.gridy = 3; p.add(new JLabel("Digite seu Nome Completo:"), gbc);
        gbc.gridy = 4; p.add(txtInscritoNome, gbc);
        gbc.gridy = 5; p.add(btnConfirmar, gbc);
        gbc.gridy = 6; p.add(btnVoltar, gbc);

        return p;
    }

    // NAVEGAÇÃO E ERRO
    private void irParaInscricao() {
        int idx = jlEventos.getSelectedIndex();

        if (idx == -1) {
            eventoSelecionado = null; 
            lblEventoTitulo.setText("ERRO: EVENTO NÃO LOCALIZADO");
            lblEventoDetalhes.setText("O ID solicitado não existe no banco de dados.");
        } else {
            eventoSelecionado = listaEventos.get(idx);
            lblEventoTitulo.setText(eventoSelecionado.getNome());
            lblEventoDetalhes.setText(eventoSelecionado.getData() + " | " + eventoSelecionado.getLocal());
        }
        
        txtInscritoNome.setText("");
        cardLayout.show(painelPrincipal, "INSCRICAO");
    }

    private void realizarInscricao() {
        if (eventoSelecionado == null) {
            JOptionPane.showMessageDialog(this, 
                "CRITICAL_ERROR: NullPointerException na referência do evento.\n" +
                "Tentativa de gravação de inscrição para evento inexistente!", 
                "Erro de Sistema", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nome = txtInscritoNome.getText();
        if (nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, digite seu nome.");
            return;
        }

        eventoSelecionado.adicionarInscrito(nome);
        salvarDados();
        JOptionPane.showMessageDialog(this, "Sucesso! Inscrição confirmada para " + nome);
        cardLayout.show(painelPrincipal, "ADM");
    }

    private void mostrarInscritos() {
        int idx = jlEventos.getSelectedIndex();
        if (idx == -1) return;
        
        Evento ev = listaEventos.get(idx);
        String lista = String.join("\n", ev.getInscritos());
        JOptionPane.showMessageDialog(this, 
            lista.isEmpty() ? "Nenhum inscrito ainda." : lista, 
            "Inscritos - " + ev.getNome(), 1);
    }
    
    private void cadastrarEvento() {
        if (txtNome.getText().isEmpty()) return;
        Evento ev = new Evento(txtNome.getText(), txtDesc.getText(), txtData.getText(), txtLocal.getText());
        listaEventos.add(ev);
        modeloLista.addElement(ev.getNome());
        salvarDados();
        txtNome.setText(""); txtDesc.setText(""); txtData.setText(""); txtLocal.setText("");
    }

    private void salvarDados() {
        try (PrintWriter w = new PrintWriter(new FileWriter(ARQUIVO))) {
            for (Evento e : listaEventos) {
                w.println(e.getNome() + ";" + e.getDescricao() + ";" + e.getData() + ";" + 
                          e.getLocal() + ";" + e.getInscritosFormatados());
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void carregarDados() {
        File f = new File(ARQUIVO);
        if (!f.exists()) return;
        try (Scanner sc = new Scanner(f)) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(";", -1);
                if (p.length >= 4) {
                    Evento ev = new Evento(p[0], p[1], p[2], p[3]);
                    if (p.length == 5 && !p[4].isEmpty()) ev.setInscritos(p[4].split(","));
                    listaEventos.add(ev);
                    modeloLista.addElement(ev.getNome());
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}